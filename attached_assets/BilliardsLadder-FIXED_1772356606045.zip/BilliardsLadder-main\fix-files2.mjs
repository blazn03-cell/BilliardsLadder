import { readFileSync, writeFileSync } from 'fs';

const files = [
  'client/src/components/ui/command.tsx',
  'client/src/components/ui/context-menu.tsx',
  'client/src/components/ui/breadcrumb.tsx',
  'client/src/components/ui/toggle.tsx',
  'client/src/components/ui/carousel.tsx',
  'client/src/components/ui/input-otp.tsx',
  'client/src/components/ui/navigation-menu.tsx',
  'client/src/components/ui/sidebar.tsx',
];

for (const f of files) {
  let c = readFileSync(f, 'utf8');
  const original = c;

  // Pattern: identifier ends a statement, then const/export/function starts next
  // e.g. "SomePrimitive.Root const Next" or "displayName const Next"
  // Match word char or dot before " const " / " export "
  c = c.replace(/([A-Za-z0-9_]) (const |export const |export type |export function |export interface |export \{)/g, '$1\n$2');

  // Pattern: ")) SomeName.displayName" — closing paren followed by identifier
  c = c.replace(/\)\) ([A-Z][A-Za-z]+\.displayName)/g, '))\n$1');

  // Already done in round 1+2 but re-run to be safe:
  c = c.replace(/(["']) (import |const |export |function |type )/g, '$1\n$2');
  c = c.replace(/([)}\]>]) (const |export |function |type )/g, '$1\n$2');
  c = c.replace(/(\.displayName = "[^"]+") (const |export |function |type )/g, '$1\n$2');
  c = c.replace(/(\.displayName = [A-Za-z._]+) (const |export |function |type )/g, '$1\n$2');

  if (c !== original) {
    writeFileSync(f, c, 'utf8');
    console.log('Fixed:', f);
  } else {
    console.log('No changes:', f);
  }
}
