// Stub transparency logs
export async function logTransparencyEvent(event: any): Promise<void> {
  // stub
}
export async function getTransparencyLogs(filter?: any): Promise<any[]> {
  return [];
}
