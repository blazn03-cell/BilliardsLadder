import { readFileSync, writeFileSync } from 'fs';

const files = [
  'client/src/components/ui/alert.tsx',
  'client/src/components/ui/aspect-ratio.tsx',
  'client/src/components/ui/breadcrumb.tsx',
  'client/src/components/ui/calendar.tsx',
  'client/src/components/ui/checkbox.tsx',
  'client/src/components/ui/command.tsx',
  'client/src/components/ui/context-menu.tsx',
  'client/src/components/ui/input-otp.tsx',
  'client/src/components/ui/navigation-menu.tsx',
  'client/src/components/ui/pagination.tsx',
  'client/src/components/ui/popover.tsx',
  'client/src/components/ui/radio-group.tsx',
  'client/src/components/ui/scroll-area.tsx',
  'client/src/components/ui/slider.tsx',
  'client/src/components/ui/toggle.tsx',
  'client/src/components/ui/carousel.tsx',
  'client/src/components/ui/sidebar.tsx',
];

for (const f of files) {
  let c = readFileSync(f, 'utf8');
  const original = c;

  // Add newline before 'import' when preceded by a closing quote on same line
  c = c.replace(/(["']) (import )/g, '$1\n$2');
  // Add newline before top-level keywords after closing quote
  c = c.replace(/(["']) (const |export |function |type )/g, '$1\n$2');
  // Add newline before top-level keywords after closing paren/brace
  c = c.replace(/([)}\]]) (const |export |function |type )/g, '$1\n$2');
  // Add newline before top-level keywords after closing angle bracket (generic type end)
  c = c.replace(/(>) (const |export |function |type )/g, '$1\n$2');
  // Add newline before top-level keywords after displayName assignments
  c = c.replace(/(\.displayName = "[^"]+") (const |export |function |type )/g, '$1\n$2');
  // Add newline before top-level keywords after .displayName = SomeVar
  c = c.replace(/(\.displayName = [A-Za-z._]+) (const |export |function |type )/g, '$1\n$2');

  if (c !== original) {
    writeFileSync(f, c, 'utf8');
    console.log('Fixed:', f);
  } else {
    console.log('No changes:', f);
  }
}
