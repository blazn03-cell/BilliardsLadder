# App

## Setup
1) Add env vars (see .env.example)
2) Install dependencies: npm install
3) Run: npm run dev (or npm start)

## Stripe
- Uses Stripe Checkout (test mode first)
- Webhook endpoint: /api/stripe/webhook
