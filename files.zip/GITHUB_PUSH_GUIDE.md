# Billiards Ladder — GitHub Push Guide

Everything is committed and ready. Here's exactly how to get it on GitHub.

---

## Step 1 — Create a GitHub repo

1. Go to **github.com** and sign in
2. Click the **+** button → **New repository**
3. Name it: `billiards-ladder`
4. Set it to **Private** (keeps your business logic hidden)
5. Do **NOT** check "Add README" or any extras — leave it blank
6. Click **Create repository**
7. Copy the URL it shows you — looks like: `https://github.com/YOURNAME/billiards-ladder.git`

---

## Step 2 — Push from your project (Replit or local)

### If you're on Replit:
Open the **Shell** tab and run these commands one at a time:

```bash
git remote add origin https://github.com/YOURNAME/billiards-ladder.git
git branch -M main
git push -u origin main
```

It will ask for your GitHub username and password.  
**Important:** GitHub no longer accepts passwords. Use a **Personal Access Token** instead:
- Go to github.com → Settings → Developer settings → Personal access tokens → Tokens (classic)
- Click "Generate new token (classic)"
- Check the **repo** checkbox
- Copy the token and use it as your password when git asks

### If working locally with the zip file:
1. Download `billiards-ladder-src.zip` from this folder
2. Unzip it into your project folder
3. Open terminal in that folder and run:

```bash
git init
git add -A
git commit -m "feat: Billiards Ladder initial commit"
git remote add origin https://github.com/YOURNAME/billiards-ladder.git
git branch -M main
git push -u origin main
```

---

## What's in the commit

### New pages added this session:
- `client/src/pages/FounderLogin.tsx` — `/founder-login` route (secret gold admin login)
- `client/src/pages/FounderDashboard.tsx` — Full control panel (rebuilt)
- `client/src/pages/RegionalOperatorDashboard.tsx` — Regional management

### Key routes:
| URL | Who sees it | Purpose |
|-----|------------|---------|
| `/founder-login` | Only you (Founder) | Secret admin login — gold luxury UI |
| `/founder-dashboard` | OWNER role only | Full control panel |
| `/regional-dashboard` | REGIONAL_OPERATOR | Regional management |
| `/login` | Everyone | Standard player/operator login |
| `/signup` | Everyone | New player registration |

### Money split (built into dashboard):
| Recipient | % | Notes |
|-----------|---|-------|
| **You (Founder)** | **23%** | Your cut from every transaction |
| Pool Hall Operators | 33% | Split among operators at that location |
| Player Prize Pool | 43% | Season pot for ladder winners |
| Platform Ops | 1% | Stripe fees, servers |

### Roles in the system:
| Role | Can do |
|------|--------|
| `OWNER` | Everything — approve everyone, see all money |
| `REGIONAL_OPERATOR` | Manage a region, invite Hall Owners |
| `POOL_HALL_OWNER` | Run their venue, invite Local Ops |
| `LOCAL_OPERATOR` | Day-to-day ops, manage players |
| `PLAYER` | Compete, challenge, win |
| `STAFF` / `TRUSTEE` | Platform admin support |

---

## Keeping it private

- Your GitHub repo is **Private** — no one can see it without your invitation
- Never commit `.env` files (they're in `.gitignore`)
- The `/founder-login` page has no link from anywhere public — it's only accessible if you know the URL

---

## Future pushes (after making changes)

```bash
git add -A
git commit -m "describe what you changed"
git push
```

That's it. Claude can run these commands for you next time if you ask.
