# Objective
Set the Stripe publishable key as `VITE_STRIPE_PUBLIC_KEY` and clean up the two mismatched/unused Stripe environment variables.

# Tasks

### T001: Set VITE_STRIPE_PUBLIC_KEY
- **Blocked By**: []
- **Details**:
  - Set `VITE_STRIPE_PUBLIC_KEY` as an environment variable with the value provided by the user (`pk_live_51RzCX3DvTG8XWAaKcXL65H0ihu9SF719Rs9IE7VHjpeAlthatXkUPvqEMHNOkCwQKNGv4sEMFnSOcB4EaEYPVNLn00zHyxgS1T`)
  - This is a publishable key (not secret), so it can be set directly via `setEnvVars`
  - Acceptance: `VITE_STRIPE_PUBLIC_KEY` is available in the environment

### T002: Remove unused/incorrect Stripe variables
- **Blocked By**: []
- **Details**:
  - Delete `STRIPE_TEST_KEY` and `STRIPE_SECRET_KEY_THIN` — both contain the webhook secret value instead of actual API keys, and neither is referenced anywhere in the codebase
  - Acceptance: These two variables no longer appear in `printenv | grep STRIPE`

### T003: Restart and verify
- **Blocked By**: [T001, T002]
- **Details**:
  - Restart the application so the frontend picks up `VITE_STRIPE_PUBLIC_KEY`
  - Verify no Stripe-related errors in browser console
  - Acceptance: App loads without Stripe key errors
